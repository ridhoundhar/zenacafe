<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="assets/img/logo.jpeg" type="image/png">
  <title>Zena Cafe Home</title>
  <!-- bootstrap -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <!-- CDN FONT AWESOME -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
      .jumbotron {
          background: linear-gradient(to bottom, rgba(255, 255, 255, 0.3), #322e2e), url('assets/img/zenaCafe.jpeg');
          background-repeat: no-repeat;
          background-position: center;
          background-size: cover;
      }
    </style>
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#"><i class="fa-brands fa-wordpress"></i> Zena Cafe</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#about">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="booking.php">Booking</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="menu.php">Menu</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#contact">Contact</a>
        </li>
      </ul>
    </div>
  </nav>

   <header class="jumbotron">
      <div class="container" style="color:rgb(185, 181, 181);">
         <h1>Welcome to Zena Cafe</h1>
         <p>Zena Cafe adalah kafe populer di Sungai Rumbai Timur, Kabupaten Dharmasraya, Sumatera Barat.</p>
         <a class="btn btn-primary btn-lg" href="#contact" role="button">Get started</a>
      </div>
   </header>

  <section id="about" class="py-5">
    <div class="container">
      <h2>About Us</h2>
      <p>Zena Cafe adalah kafe populer di Sungai Rumbai Timur, Kabupaten Dharmasraya, Sumatera Barat. Dengan desain modern namun dipenuhi dengan sentuhan tradisional, kafe ini menawarkan makanan lezat, termasuk hidangan tradisional Minangkabau. Pengunjung dapat menikmati suasana nyaman dengan dekorasi yang memikat sambil menikmati minuman segar. Zena Cafe juga sering menjadi tempat untuk acara khusus dan terlibat dalam kegiatan sosial di komunitas sekitar.</p>
    </div>
  </section>

  <section id="services" class="py-5 bg-light">
    <div class="container">
      <h2>Layanan</h2>
      <div class="row">
        <div class="col-md-6">
          <div class="card mb-4">
            <div class="card-body">
              <h5 class="card-title">Booking Meja</h5>
              <p class="card-text">Anda dapat melakukan pemesanan meja di Zena Cafe dengan mudah. Hubungi nomor telepon yang tertera atau kunjungi situs web kami untuk melakukan reservasi. Dalam pemesanan, pastikan untuk memberikan informasi seperti tanggal dan waktu kedatangan, jumlah orang, serta preferensi tempat duduk Dengan memesan meja sebelumnya, Anda dapat menghindari antrian dan memastikan tempat yang nyaman untuk menikmati hidangan Anda.</p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card mb-4">
            <div class="card-body">
              <h5 class="card-title">Menu</h5>
              <p class="card-text">Zena Cafe menawarkan menu makanan yang beragam dan lezat.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <section id="contact" class="py-5">
    <div class="container">
      <h2>Contact Us</h2>
      <form method="POST" action="/submit-form">
        <div class="form-group">
          <label for="name">Nama</label>
          <input type="text" class="form-control" id="name" placeholder="Masukan Nama">
        </div>
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" class="form-control" id="email" placeholder="contoh@gmail.com">
        </div>
        <div class="form-group">
          <label for="message">Pesan</label>
          <textarea class="form-control" id="message" rows="3" placeholder=""></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </section>

  <footer class="py-4 text-center bg-light">
      <div class="container">
        <p>&copy; 2023 <a href="https://undhari.ac.id/web/prodi-filkom/s1-sistem-informasi.html">Sistem Informasi</a></p>
          <div class="social-media">
              <a href="https://www.facebook.com/namamediasosial" target="_blank"><i class="fab fa-facebook"></i></a>
              <a href="https://www.twitter.com/namamediasosial" target="_blank"><i class="fab fa-twitter"></i></a>
              <a href="https://www.instagram.com/namamediasosial" target="_blank"><i class="fab fa-instagram"></i></a>
          </div>
        <p>Zena Cafe, Sungai Rumbai Timur, Kabupaten Dharmasraya, Sumatera Barat</p>
      </div>
  </footer>

<script>
  document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault(); // Mencegah form dikirimkan secara default

    // Ambil nilai dari input Nama, Email, dan Pesan
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var message = document.getElementById('message').value;

    // Buat URL dengan nomor WhatsApp dan pesan yang telah diformat
    var whatsappURL = 'https://wa.me/+62082211964970?text=' + encodeURIComponent('Nama: ' + name + '\nEmail: ' + email + '\nPesan: ' + message);

    // Buka URL WhatsApp dalam tab baru
    window.open(whatsappURL, '_blank');
  });
//  mengirim conact us dengan twilio menggunkan ketika di hosting
      // const express = require('express');
      // const bodyParser = require('body-parser');
      // const twilio = require('twilio');

      // const app = express();
      // app.use(bodyParser.urlencoded({ extended: false }));

      // const accountSid = 'ACfb0489d82fc91a79e82695e63bbf08a5';
      // const authToken = 'ed45756bab4d5dae2ffb6ffff8aeb46d';
      // const client = twilio(accountSid, authToken);

      // function sendWhatsAppMessage(sender, message) {
      // const recipient = 'whatsapp:' + sender; 
      // client.messages
      //    .create({
      //       body: message,
      //       from: 'whatsapp:+14066922866', 
      //       to: recipient
      //    })
      //    .then(message => console.log('Message sent: ' + message.sid))
      //    .catch(error => console.log('Error sending message: ' + error));
      // }
      // app.post('/submit-form', (req, res) => {
      // const name = req.body.name;
      // const email = req.body.email;
      // const message = req.body.message;
      // const senderNumber = '082132429371'; Nomor pengirim (ganti dengan nomor yang sesuai)
      // const text = `Nama: ${name}\nEmail: ${email}\nPesan: ${message}`;
      // sendWhatsAppMessage(senderNumber, text);


      // res.redirect('/success');
      // });

      // app.listen(3000, () => {
      // console.log('Server started on port 3000');
      // });


</script>


  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.min.js"></script>
</body>

</html>