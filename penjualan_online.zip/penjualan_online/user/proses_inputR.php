<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="This is a brief description of the webpage.">
    <meta name="keywords" content="keyword1, keyword2, keyword3">
    <meta name="author" content="Author Name">
    <meta name="robots" content="index,follow">
    <title>Struct Pembayara</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="icon" href="assets/img/logo.jpeg" type="image/png">
    <link rel="stylesheet" href="assets/css/proses_input.css">

</head>

<body class="container">
    <div class="mt-4 payment-slip">
        <?php
        $tanggal = $_POST['tanggal'];
        $waktu = $_POST['waktu'];
        $nama_pemesan = $_POST['nama_pemesan'];
        $email_pemesan = $_POST['email_pemesan'];
        $telepon_pemesan = $_POST['telepon_pemesan'];
        $metode_pembayaran = $_POST['metode_pembayaran'];
        $id_meja = $_POST['id_meja'];

        echo "<h1>Pembayaran:</h1>";
        echo "<p>Tanggal: " . $tanggal . "</p>";
        echo "<p>Waktu: " . $waktu . "</p>";
        echo "<p>Nama Pemesan: " . $nama_pemesan . "</p>";
        echo "<p>Email Pemesan: " . $email_pemesan . "</p>";
        echo "<p>Telepon Pemesan: " . $telepon_pemesan . "</p>";
        echo "<p>Metode Pembayaran: " . $metode_pembayaran . "</p>";
        echo "<p>ID Meja: " . $id_meja . "</p>";

        
        include "../koneksi.php";

        $updateSql = "UPDATE meja SET status = 'dipesan' WHERE nomor_meja = '$id_meja'";
        $updateResult = $con->query($updateSql);

        if ($updateResult) {
            echo "<p>Meja Berhasil Di booking.</p>";
        } else {
            echo "<p>Gagal Booking Meja.</p>";
        }

        $insertSql = "INSERT INTO reservasi (tanggal, waktu, nama_pemesan, email_pemesan, telepon_pemesan, metode_pembayaran, id_meja) VALUES ('$tanggal', '$waktu', '$nama_pemesan', '$email_pemesan', '$telepon_pemesan', '$metode_pembayaran', '$id_meja')";
        $insertResult = $con->query($insertSql);

        if ($insertResult) {
            echo "<p>Segera Lakukkan Pembayar.</p>";
        } else {
            echo "<p>Maaf.</p>";
        }

        if ($metode_pembayaran == 'Transfer Bank') {
            $bankDetailsSql = "SELECT * FROM meja WHERE id_meja = '$id_meja'";
            $bankDetailsResult = $con->query($bankDetailsSql);

            if ($bankDetailsResult->num_rows > 0) {
                $randomAccountNumber = rand(1000000000000, 999999999);
                $bankName = "BRI";
                $Zena_Cafe = "-Zc";
                echo "<div class='bank-details'>";
                echo "<h2>Transfer Bank:</h2>";
                echo "<p>Nama Bank: " . $bankName . "</p>";
                echo "<p>Nomor Rekening: " . $randomAccountNumber . $Zena_Cafe . "</p>";
                echo "<p>Jumlah Pembayaran: Rp50.000</p>";
                echo "<img src='https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl' style='width:150px;' >";
                echo "<p>Waktu tersisa: <span id='countdown'></span></p>";
                echo "</div>";

                $expirationTime = strtotime('+30 minutes');
                $currentDateTime = time();
                $countdown = $expirationTime - $currentDateTime;

                echo "<script>";
                echo "var countdown = " . $countdown . ";";
                echo "var timer = setInterval(function() {";
                echo "    var minutes = Math.floor(countdown / 60);";
                echo "    var seconds = countdown % 60;";
                echo "    document.getElementById('countdown').innerHTML = minutes + ' menit ' + seconds + ' detik';";
                echo "    countdown--;";
                echo "    if (countdown < 0) {";
                echo "        clearInterval(timer);";
                echo "        document.getElementById('countdown').innerHTML = 'Waktu habis';";
                echo "    }";
                echo "}, 1000);";
                echo "</script>";
            }
        } elseif ($metode_pembayaran == 'Cash') {
            echo "<p>Harap segera melakukan pembayaran dengan uang tunai.</p>";
        }



        mysqli_close($con);
        ?>
    </div>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>