<!DOCTYPE html>
<html>

<head>
    <title>Struk Pembayaran</title>
    <link rel="icon" href="assets/img/logo.jpeg" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 15px;
            font-size: 14px;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            border: 1px solid #ccc;
            padding: 20px;
            background-color: #f9f9f9;
        }

        .container h1,
        h2 {
            font-size: 30px;
        }

        .info {
            margin-bottom: 10px;
        }

        .info span {
            font-weight: bold;
        }

        .barcode {
            text-align: center;
            margin-top: 20px;
        }

        .barcode img {
            max-width: 100%;
        }

        .rekening {
            text-align: center;
            margin-top: 10px;
            font-weight: bold;
            font-size: 16px;
        }
    </style>
</head>

<body>
    <?php
    include "../koneksi.php";

    // Menerima parameter ID reservasi
    $id_reservasi = $_GET['id'];

    // Query untuk mendapatkan detail reservasi berdasarkan ID
    $query = "SELECT r.*, m.harga FROM reservasi r INNER JOIN meja m ON r.id_meja = m.id_meja WHERE r.id_reservasi = $id_reservasi";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);
    ?>

    <div class="container">
        <h1 class="text-center">Struk Pembayaran</h1>
        <div class="info">
            <span>ID Reservasi:</span>
            <?php echo $row['id_reservasi']; ?>
        </div>
        <div class="info">
            <span>Nomor Meja:</span>
            <?php echo getNomorMeja($con, $row['id_meja']); ?>
        </div>
        <div class="info">
            <span>Tanggal:</span>
            <?php echo $row['tanggal']; ?>
        </div>
        <div class="info">
            <span>Waktu:</span>
            <?php echo $row['waktu']; ?>
        </div>
        <div class="info">
            <span>Nama Pemesan:</span>
            <?php echo $row['nama_pemesan']; ?>
        </div>
        <div class="info">
            <span>Email Pemesan:</span>
            <?php echo $row['email_pemesan']; ?>
        </div>
        <div class="info">
            <span>Telepon Pemesan:</span>
            <?php echo $row['telepon_pemesan']; ?>
        </div>
        <div class="info">
            <span>Harga:</span> Rp.
            <?php echo number_format($row['harga'], 0, ',', '.'); ?>
        </div>

        <!-- Tampilkan metode pembayaran -->
        <h2 class="mt-4">Metode Pembayaran</h2>
        <form action="proses_pembayaran.php" method="post">
            <input type="hidden" name="id_reservasi" value="<?php echo $row['id_reservasi']; ?>">
            <div class="form-group">
                <label for="metode_pembayaran">Metode Pembayaran</label>
                <select class="form-control" name="metode_pembayaran" id="metode_pembayaran">
                    <option value="transfer_bank">Transfer Bank</option>
                    <option value="cash">Tunai/Cash</option>
                </select>
            </div>
            <input type="submit" class="btn btn-primary" value="Bayar">
        </form>

        <div class="barcode">
            <img src="<?php echo generateBarcode($row['nomor_rekening']); ?>" alt="Barcode">
        </div>

        <div class="rekening">
            Nomor Rekening:
            <?php echo generateNomorRekening($row['id_reservasi']); ?>
        </div>
    </div>

    <?php
    // Fungsi untuk mendapatkan nomor meja berdasarkan ID meja
    function getNomorMeja($con, $id_meja)
    {
        $query = "SELECT nomor_meja FROM meja WHERE id_meja = $id_meja";
        $result = mysqli_query($con, $query);
        $row = mysqli_fetch_assoc($result);
        return $row['nomor_meja'];
    }

    // Fungsi untuk menghasilkan nomor rekening berdasarkan ID reservasi
    function generateNomorRekening($id_reservasi)
    {
        $nomor_rekening = 'REK' . str_pad($id_reservasi, 6, '0', STR_PAD_LEFT);
        return $nomor_rekening;
    }

    // Fungsi untuk menghasilkan barcode
    function generateBarcode($text)
    {
        $barcodeUrl = "https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl=" . urlencode($text);
        return $barcodeUrl;
    }

    // Tutup koneksi database
    mysqli_close($con);
    ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.0/js/bootstrap.min.js"></script>
</body>

</html>