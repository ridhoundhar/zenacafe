<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/logo.jpeg" type="image/png">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Zena Cafe Booking</title>

    <link rel="stylesheet" href="assets/css/boking.css">
    <style>

    </style>
</head>

<body>
    <div class="container">
        <a href="index.php">Kembali</a>
        <div class="row">
            <div class="col-md-6">
                <div class="image-container">
                    <img src="assets/img/meja.jpeg" alt="">
                </div>
            </div>
            <div class="row">
                <div class="col-md-100">
                    <?php
                    include "../koneksi.php";

                    if (isset($_GET['no'])) {
                        $nomor_meja = $_GET['no'];
                        $sql = "SELECT * FROM meja WHERE nomor_meja = '$nomor_meja'";
                        $result = $con->query($sql);

                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            echo "<h1 class='mt-4'>Booking Meja No " . $row['nomor_meja'] . "</h1>";
                            echo "<p>Status: " . $row['status'] . "</p>";
                            echo "<p>Harga: Rp" . $row['harga'] . "</p>";

                            if ($row['status'] == 'dipesan') {
                                echo "<p>Meja sudah dipesan</p>";
                            } else {
                                echo "<form action='' method='get'>";
                                echo "<input type='hidden' name='no' value='" . $row['nomor_meja'] . "'>";
                                echo "<button type='button' value='" . $row['nomor_meja'] . "' class='btn btn-primary mt-3' onclick='showPopup()' id='bayarButton'>Bayar</button>";
                                echo "</form>";
                            }
                        } else {
                            echo "<h1 class='mt-4'>Error: Meja not found</h1>";
                        }
                    } else {
                        echo "<p>Kembali Ke halaman" . "<a href='index.php'> Utama</a>" . "</p>";
                    }

                    mysqli_close($con);
                    ?>
                </div>
            </div>
        </div>
    </div>

<!-- conten booking -->
<div class="formBoking" id="formBoking">
    <button class="btn btn-close" id="btnClose" style="margin-left: 520px;">X</button>
    <?php
        $con = mysqli_connect("localhost", "root", "", "penjualan_db");

            if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_errno();
            exit();
        }

        if (isset($_GET['no'])) {
            $nomor_meja = $_GET['no'];
            $sql = "SELECT * FROM meja WHERE nomor_meja = '$nomor_meja'";
            $result = $con->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo "<div class='none' style='display:none;'>";
                echo "<p class='' style='display:none;'>Booking Meja No " . $row['nomor_meja'] . "</p>";
                echo "<p>Status: " . $row['status'] . "</p>";
                echo "<p>Harga: Rp" . $row['harga'] . "</p>";
                echo "</div>";

                if ($row['status'] == 'dipesan') {
                    echo "<p>Meja sudah dipesan</p>";
                } else {
                    echo "<form method='POST' action='proses_inputR.php'>";
                    echo "<input type='hidden' name='id_meja' value='" . $row['id_meja'] . "'>";

                    echo "<div class='form-group'>";
                    echo "<label for='tanggal'>Tanggal:</label>";
                    echo "<input type='date' id='tanggal' name='tanggal' class='form-control' required>";
                    echo "</div>";

                    echo "<div class='form-group'>";
                    echo "<label for='waktu'>Waktu:</label>";
                    echo "<input type='time' id='waktu' name='waktu' class='form-control' required>";
                    echo "</div>";

                    echo "<div class='form-group'>";
                    echo "<label for='nama_pemesan'>Nama Pemesan:</label>";
                    echo "<input type='text' id='nama_pemesan' name='nama_pemesan' class='form-control' required>";
                    echo "</div>";

                    echo "<div class='form-group'>";
                    echo "<label for='email_pemesan'>Email Pemesan:</label>";
                    echo "<input type='email' id='email_pemesan' name='email_pemesan' class='form-control' required>";
                    echo "</div>";

                    echo "<div class='form-group'>";
                    echo "<label for='telepon_pemesan'>Telepon Pemesan:</label>";
                    echo "<input type='tel' id='telepon_pemesan' name='telepon_pemesan' class='form-control' required>";
                    echo "</div>";

                    echo "<div class='form-group'>";
                    echo "<label for='metode_pembayaran'>Metode Pembayaran:</label>";
                    echo "<select id='metode_pembayaran' name='metode_pembayaran' class='form-control' required>";
                    echo "<option value=''>Cash</option>";
                    echo "<option value='Transfer Bank'>Transfer Bank</option>";
                    echo "<option value='Cash'>Cash</option>";
                    echo "</select>";
                    echo "</div>";

                    echo "<div class='form-group' style='display:none;'>";
                    echo "<label for='id_meja'>ID Meja:</label>";
                    echo "<input type='text' id='id_meja' name='id_meja' value='" . $row['id_meja'] . "' class='form-control' readonly required>";
                    echo "</div>";

                    echo "<input type='submit' value='Booking' class='btn btn-primary'>";
                    echo "</form>";
                }
            } else {
                echo "<h1 class='mt-4'>Error: Meja not found</h1>";
            }
        } else {
            echo "<p>Kembali Ke halaman" . "<a href='index.php'> Utama</a>" . "</p>";
        }

        mysqli_close($con);
    ?>   

</div>





    <script>
        const btnClose = document.querySelector('#btnClose');
        const bayarButton = document.getElementById('bayarButton');
        const formBoking = document.getElementById('formBoking');

        bayarButton.addEventListener("click", function() {
            formBoking.classList.toggle("moved");
        });
        btnClose.addEventListener("click", function() {
            formBoking.classList.toggle("ubah");
        });

    </script>

</body>

</html>
