<!DOCTYPE html>
<html>

<head>
    <title>Booking Confirmation</title>
</head>

<body>
    <?php
    function generateImage($text)
    {
        $imageWidth = 200;
        $imageHeight = 200;
        $image = imagecreate($imageWidth, $imageHeight);
        $backgroundColor = imagecolorallocate($image, 255, 255, 255);
        $textColor = imagecolorallocate($image, 0, 0, 0);

        // Generate QR code
        $qrCode = generateQRCode($text, $imageWidth);

        $qrCodeWidth = imagesx($qrCode);
        $qrCodeHeight = imagesy($qrCode);
        $qrCodeX = ($imageWidth - $qrCodeWidth) / 2;
        $qrCodeY = ($imageHeight - $qrCodeHeight) / 2;

        imagecopy($image, $qrCode, $qrCodeX, $qrCodeY, 0, 0, $qrCodeWidth, $qrCodeHeight);

        header('Content-Type: image/png');
        imagepng($image);
        imagedestroy($image);
        imagedestroy($qrCode);
    }

    function generateQRCode($text, $size)
    {
        $data = urlencode($text);
        $url = "https://api.qrserver.com/v1/create-qr-code/?data=$data&size={$size}x{$size}";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        $qrCodeData = curl_exec($ch);
        curl_close($ch);

        $qrCodeImage = imagecreatefromstring($qrCodeData);
        return $qrCodeImage;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_GET['nama_pemesan'])) {
            $nama_pemesan = $_GET['nama_pemesan'];
            generateImage($nama_pemesan);
        } else {
            echo "No nama pemesan provided.";
        }
    } else {
        echo "This page is meant to be accessed via a GET request.";
    }
    ?>
</body>

</html>