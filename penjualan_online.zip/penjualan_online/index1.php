<?php
session_start();

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('Location:login.php');
    exit();
}

$username = $_SESSION['username'];

// jumlah meja
require "../koneksi.php";

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

$sql = "SELECT COUNT(*) AS jumlah_meja FROM meja";
$result = $con->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $jumlah_meja = $row["jumlah_meja"];
} else {
    echo "Error: " . mysqli_error($con);
}

// meja tersedia
$sql = "SELECT COUNT(*) AS jumlah_meja FROM meja WHERE status = 'tersedia'";
$result = $con->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $jumlah_meja_tersedia = $row["jumlah_meja"];
} else {
    echo "Error: " . mysqli_error($con);
}

// pendapatan
$sql = "SELECT SUM(harga) AS total_duit FROM meja";
$result = $con->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $total_duit = $row["total_duit"];
} else {
    echo "Error: " . mysqli_error($con);
}

$con->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>


    <!-- css -->
    <link rel="stylesheet" href="assets/css/index.css">

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

    <!-- CDN FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
            <img src="assets/img/baju1.jpeg" alt="Admin Logo" width="30" height="30" class="d-inline-block align-top">
            Zena Cafe
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="#">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Settings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-action active">Dashboard</a>
                    <a href="#" class="list-group-item list-group-item-action">Users</a>
                    <a href="#" class="list-group-item list-group-item-action">Products</a>
                    <a href="#" class="list-group-item list-group-item-action">Orders</a>
                    <a href="#" class="list-group-item list-group-item-action">Reports</a>
                </div>
            </div>
            <div class="col-md-9">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search...">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="button">Search</button>
                    </div>
                </div><br>
                <div class="flex-container container_content">
                    <div class="box">
                        <h4>Jumlah Meja</h4>
                        <p>
                            <?php echo $jumlah_meja; ?> <i class="fa-solid fa-table"></i>
                        </p>
                    </div>
                    <div class="box">
                        <h4>Meja Tersedia</h4>
                        <p>
                            <?php echo $jumlah_meja_tersedia; ?> <i class="fa-solid fa-table"></i>
                        </p>
                    </div>
                    <div class="box">
                        <h4>pengeluaran</h4>
                        <?php echo '<p>Rp' . $total_duit . '</p>'; ?>
                    </div>
                    <div class="box">
                        <h4>Pendapatan</h4>
                        <?php
                        $con = mysqli_connect("localhost", "root", "", "penjualan_db");

                        if (mysqli_connect_errno()) {
                            echo "Failed to connect to MySQL : " . mysqli_connect_errno();
                            exit();
                        }
                        $sql = "SELECT SUM(harga) AS total_duit FROM meja WHERE status = 'dipesan'";
                        $result = $con->query($sql);

                        if ($result) {
                            $row = $result->fetch_assoc();
                            $total_duit = $row["total_duit"];
                            echo '<p class="number"> Rp' . $total_duit . '</p>';
                        } else {
                            echo "Error: " . $con->error;
                        }

                        $con->close();
                        ?>
                    </div>
                </div>



                <!-- isi content daftar meja -->
                <div class="box-meja" style="backgoriund:#aeaeaeae;">
                    <div class="meja" style="height: 400px; overflow-y: auto;">
                        <?php
                        $con = mysqli_connect("localhost", "root", "", "penjualan_db");

                        if (mysqli_connect_errno()) {
                            echo "Failed to connect to MySQL: " . mysqli_connect_errno();
                            exit();
                        }

                        $sql = "SELECT * FROM meja";
                        $result = $con->query($sql);

                        if ($result->num_rows > 0) {
                            echo '<form method="POST" id="mejaForm">';
                            echo '<table class="table">';
                            echo '<thead>';
                            echo '<tr>';
                            echo '<th scope="col">No Meja</th>';
                            echo '<th scope="col">Harga</th>';
                            echo '<th scope="col">Status</th>';
                            echo '<th scope="col">Pilih</th>';
                            echo '<th scope="col">Edit</th>';
                            echo '</tr>';
                            echo '</thead>';
                            echo '<tbody>';

                            while ($row = $result->fetch_assoc()) {
                                $nomor_meja = $row["nomor_meja"];
                                $harga = $row["harga"];
                                $status = $row["status"];

                                echo '<tr>';
                                echo '<td>' . $nomor_meja . '</td>';
                                echo '<td>Rp' . $harga . '</td>';
                                echo '<td>' . $status . '</td>';
                                echo '<td><input type="checkbox" name="selectedMeja[]" value="' . $nomor_meja . '"></td>';
                                echo '<td><a type="button" class="editButton" data-meja="' . $nomor_meja . '">Edit</a></td>';

                                echo '</tr>';
                            }

                            echo '</tbody>';
                            echo '</table>';
                            echo '<input type="submit" value="Submit">';
                            echo '</form>';



                        }

                        $con->close();
                        ?>

                        <!-- pop up edit status meja  -->
                        <div class="edit-meja" id="editmeja" style="display: none;">
                            <form method="POST" action="editstatus.php">
                                <input type="hidden" name="nomor_meja" id="editNomorMeja">

                                <div class="form-group">
                                    <label for="status">Ubah Status:</label>
                                    <select class="form-control" name="status" id="status">
                                        <option value="tersedia" <?php if ($status == 'tersedia')
                                            echo ' selected'; ?>>
                                            Tersedia</option>
                                        <option value="dipesan" <?php if ($status == 'dipesan')
                                            echo ' selected'; ?>>
                                            Dipesan</option>
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-primary">Submit</button>
                            </form>

                        </div>



                    </div>

                </div>
            </div>

        </div>
    </div>










    <!-- script -->
    <script>
        $(document).ready(function () {
            $(".navbar-toggler").click(function () {
                $("#navbarNav").collapse("toggle");
            });
        });

        // tombol pop up edit meja
        const form = document.getElementById('mejaForm');
        const checkboxes = form.querySelectorAll('input[type="checkbox"]');
        const editMejaDiv = document.getElementById('editmeja');
        let isMoving = false;
        let offsetX = 0;
        let offsetY = 0;

        checkboxes.forEach(function (checkbox) {
            checkbox.addEventListener('click', function () {
                if (checkbox.checked) {
                    const selectedMeja = checkbox.value;
                    editMejaDiv.style.display = 'block';
                    const nomorMejaInput = editMejaDiv.querySelector('#editNomorMeja');
                    nomorMejaInput.value = selectedMeja;
                } else {
                    editMejaDiv.style.display = 'none';
                }
            });
        });

        editMejaDiv.addEventListener('mousedown', function (e) {
            isMoving = true;
            offsetX = e.clientX - editMejaDiv.offsetLeft;
            offsetY = e.clientY - editMejaDiv.offsetTop;
        });

        document.addEventListener('mousemove', function (e) {
            if (isMoving) {
                editMejaDiv.style.left = e.clientX - offsetX + 'px';
                editMejaDiv.style.top = e.clientY - offsetY + 'px';
            }
        });

        document.addEventListener('mouseup', function () {
            isMoving = false;
        });


        const editButtons = document.querySelectorAll('.editButton');
        editButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                const selectedMeja = button.getAttribute('data-meja');
                const editMejaDiv = document.getElementById('editmeja');
                editMejaDiv.style.display = 'block';

                const nomorMejaInput = editMejaDiv.querySelector('#editNomorMeja');
                nomorMejaInput.value = selectedMeja;
            });
        });

    </script>

</body>

</html>