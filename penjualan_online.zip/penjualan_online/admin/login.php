<?php
session_start();
require "../koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="assets/img/logo.jpeg" type="image/png">
    <title>login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>
<style>
    .main {
        height: 100vh;
    }

    .login {
        width: 500px;
        height: 300px;
        box-shadow: 1px 1px 10px #aeaeaeae;
        border-radius: 15px;
        box-sizing: border-box;
    }

    /* alertlogin */
    .alertlogin {
        box-sizing: border-box;
        padding: 2px;
        text-align: center;
        font-size: 12px;
    }
</style>

<body>
    <div class="main d-flex justify-content-center align-items-center">
        <div class="login p-4">
            <form action="" method="post">
                <h2 class="text-center">Login Admin</h2>
                <div>
                    <label for="username">Username</label>
                    <input type="text" name="username" class="form-control" id="username" placeholder="Username">
                </div>
                <div>
                    <label for="password">Password</label>
                    <input type="password" name="password" class="form-control" id="password">
                </div>
                <div>
                    <button class="btn btn-success form-control mt-4" type="submit" name="login">Login</button>
                </div>
            </form>

            <div>
                <?php
                if (isset($_POST['login'])) {
                    $username = htmlspecialchars($_POST['username']);
                    $password = htmlspecialchars($_POST['password']);
                    $query = mysqli_query($con, "SELECT * FROM users WHERE username = '$username'");
                    $countdata = mysqli_num_rows($query);
                    if (isset($_POST['login'])) {
                        $username = htmlspecialchars($_POST['username']);
                        $password = htmlspecialchars($_POST['password']);
                        $query = mysqli_query($con, "SELECT * FROM users WHERE username = '$username'");
                        $countdata = mysqli_num_rows($query);
                        if ($countdata > 0) {
                            $_SESSION['login'] = true;
                            $_SESSION['username'] = $username;
                            header('Location: ../admin');
                            exit();
                        } else {
                            $_SESSION['login'] = false;
                            ?>
                            <div class="alert alert-danger alertlogin mt-2" role="alert">
                                Username Salah!
                            </div>
                            <?php
                        }
                    }
                }
                ?>
            </div>
        </div>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
        crossorigin="anonymous"></script>
</body>

</html>