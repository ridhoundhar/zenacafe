<!DOCTYPE html>
<html>

<head>
    <title>Proses Pembayaran</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            text-align: center;
        }

        .success-message {
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>

<body>
    <?php
    include "../koneksi.php";

    // Menerima data dari formulir
    $id_reservasi = $_POST['id_reservasi'];
    $metode_pembayaran = $_POST['metode_pembayaran'];

    // Update status pembayaran
    $query_update = "UPDATE reservasi SET metode_pembayaran = '$metode_pembayaran', status_pembayaran = 'lunas' WHERE id_reservasi = $id_reservasi";
    $result_update = mysqli_query($con, $query_update);

    if ($result_update) {
        echo "<h1>Pembayaran berhasil!</h1>";
        echo "<div class='success-message'>Terima kasih telah melakukan pembayaran.</div>";
    } else {
        echo "<h1>Pembayaran gagal.</h1>";
        echo "<div class='success-message'>Silakan coba lagi.</div>";
    }

    // Tutup koneksi database
    mysqli_close($con);
    ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.0/js/bootstrap.min.js"></script>
</body>

</html>