<?php
session_start();

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('Location:login.php');
    exit();
}

$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="shortcut icon" href="assets/img/logo.jpeg" type="image/x-icon">

    <!-- css -->
    <!-- <link rel="stylesheet" href="assets/css/history.css"> -->

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

    <!-- CDN FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
        }

        .profile-container {
            width: 400px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
        }

        .profile-image {
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-image img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #fff;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.2);
        }

        .profile-info {
            margin-top: 20px;
        }

        .profile-info p {
            margin: 5px 0;
        }

        .profile-info p strong {
            font-weight: bold;
        }

        .logout-link {
            margin-top: 200px;
            bottom: 20px;
            left: 20px;
        }
    </style>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
            <img src="assets/img/logo.jpeg" alt="Admin Logo" width="30" height="30" class="d-inline-block align-top">
            Zena Cafe
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="setting.php">Settings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="list-group">
                    <a href="index.php" class="list-group-item list-group-item-action">Dashboard</a>
                    <a href="Meja.php" class="list-group-item list-group-item-action">Meja</a>
                    <a href="menu.php" class="list-group-item list-group-item-action">Menu</a>
                    <a href="history.php" class="list-group-item list-group-item-action">Reports</a>
                </div>
            </div>
            <div class="col-md-9">
                <div class="flex-container container_content">
                    <div class="profile-container">
                        <div class="profile-image">
                            <img src="assets/img/logo.jpeg" alt="Profil Saya">
                        </div>
                        <div class="profile-info">
                            <p><strong>Nama:</strong>
                                <?php echo $username ?>
                            </p>
                            <p><strong>Usia:</strong> 25 Tahun</p>
                            <p><strong>Alamat:</strong> Jl. Dharmasraya</p>
                            <p><strong>Email:</strong> dharmas@gmail.com</p>
                            <p><strong>Telepon:</strong> 1234567890</p>
                            <a class="nav-link logout-link" href="logout.php">Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>










    <!-- script -->
    <script>


    </script>

</body>

</html>