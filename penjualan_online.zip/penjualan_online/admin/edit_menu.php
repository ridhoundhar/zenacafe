<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])) {
    $id_menu = $_GET["id"];

    
    include "../koneksi.php";
    $sql = "SELECT * FROM menu WHERE id_menu = '$id_menu'";
    $result = $con->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $nama_menu = $row["nama_menu"];
        $harga = $row["harga"];
        $status = $row["status"];
    } else {
        echo "Menu not found";
        exit();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id_menu"])) {
    $id_menu = $_POST["id_menu"];
    $nama_menu = $_POST["nama_menu"];
    $harga = $_POST["harga"];
    $status = $_POST["status"];

    
    include "../koneksi.php";

    $updateSql = "UPDATE menu SET nama_menu='$nama_menu', harga='$harga', status='$status' WHERE id_menu='$id_menu'";
    if ($con->query($updateSql) === TRUE) {
        echo '<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>';
        echo '<script>
            document.addEventListener("DOMContentLoaded", function() {
                swal({
                    title: "Data berhasil diupdate",
                    icon: "success",
                    button: "OK"
                }).then(function() {
                    window.location.href = "menu.php";
                });
            });
        </script>';
    } else {
        echo "Gagal mengupdate data";
    }

    $con->close();
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Menu</title>
    <link rel="icon" href="assets/img/logo.jpeg" type="image/png">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.5/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.5/dist/sweetalert2.all.min.js"></script>
</head>
    <style>
        .container {
            margin: 100px auto;
        }
    </style>
<body>
    <div class="container">
    <h3><?php echo $nama_menu; ?></h3>
    <form method="POST">
        <input type="hidden" name="id_menu" value="<?php echo $id_menu; ?>">
        <div class="form-group">
            <label for="nama_menu">Nama Menu:</label>
            <input type="text" class="form-control" name="nama_menu" value="<?php echo $nama_menu; ?>">
        </div>

        <div class="form-group">
            <label for="harga">Harga:</label>
            <input type="text" class="form-control" name="harga" value="<?php echo $harga; ?>">
        </div>

        <div class="form-group">
            <label for="status">Status:</label>
            <select class="form-control" name="status">
                <option value="Tersedia" <?php if ($status == 'tersedia') echo 'selected'; ?>>Tersedia</option>
                <option value="Habis" <?php if ($status == 'habis') echo 'selected'; ?>>Habis</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>


    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
