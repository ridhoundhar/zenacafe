<?php
session_start();

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('Location:login.php');
    exit();
}

$username = $_SESSION['username'];

// jumlah menu
require "../koneksi.php";

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

$sql = "SELECT COUNT(*) AS jumlah_menu FROM menu";
$result = $con->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $jumlah_menu = $row["jumlah_menu"];
} else {
    echo "Error: " . mysqli_error($con);
}

// menu tersedia
$sql = "SELECT COUNT(*) AS jumlah_menu FROM menu WHERE status = 'tersedia'";
$result = $con->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $jumlah_menu_tersedia = $row["jumlah_menu"];
} else {
    echo "Error: " . mysqli_error($con);
}

// pendapatan
$sql = "SELECT SUM(harga) AS total_duit FROM menu";
$result = $con->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $total_duit = $row["total_duit"];
} else {
    echo "Error: " . mysqli_error($con);
}

$con->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="icon" href="assets/img/logo.jpeg" type="image/png">


    <!-- css -->
    <link rel="stylesheet" href="assets/css/index.css">

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

    <!-- CDN FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
            <img src="assets/img/baju1.jpeg" alt="Admin Logo" width="30" height="30" class="d-inline-block align-top">
            Zena Cafe
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="setting.php">Settings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="list-group">
                    <a href="index.php" class="list-group-item list-group-item-action">Dashboard</a>
                    <a href="Meja.php" class="list-group-item list-group-item-action">Meja</a>
                    <a href="menu.php" class="list-group-item list-group-item-action active">Menu</a>
                    <a href="history.php" class="list-group-item list-group-item-action">Reports</a>
                </div>
            </div>
            <div class="col-md-9">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search...">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="button">Search</button>
                    </div>
                </div><br>
                <div class="flex-container container_content">
                    <div class="box">
                        <h4>Menu Makanan</h4>
                        <p>
                            <?php echo $jumlah_menu; ?> <i class="fa-solid fa-table"></i>
                        </p>
                    </div>
                    <div class="box">
                        <h4>Menu Tersedia</h4>
                        <p>
                            <?php echo $jumlah_menu_tersedia; ?> <i class="fa-solid fa-table"></i>
                        </p>
                    </div>
                    <div class="box">
                        <h4>pengeluaran</h4>
                        <?php echo '<p>Rp' . $total_duit . '</p>'; ?>
                    </div>
                    <div class="box">
                        <h4>Pendapatan</h4>
                        <?php
                        include "../koneksi.php";
                        $sql = "SELECT SUM(harga) AS total_duit FROM menu WHERE status = 'habis'";
                        $result = $con->query($sql);

                        if ($result) {
                            $row = $result->fetch_assoc();
                            $total_duit = $row["total_duit"];
                            echo '<p class="number"> Rp' . $total_duit . '</p>';
                        } else {
                            echo "Error: " . $con->error;
                        }

                        $con->close();
                        ?>
                    </div>
                </div>



<!-- isi content daftar menu -->
<div class="box-meja">
    <div class="meja" style="height: 400px; overflow-y: auto;">
        <h2>Menu Makanan</h2>
        <?php
$con = mysqli_connect("localhost", "root", "", "penjualan_db");

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_errno();
    exit();
}

$sql = "SELECT * FROM menu";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    echo '<table class="table">';
    echo '<thead class="">';
    echo '<tr>';
    echo '<th scope="col">No</th>';
    echo '<th scope="col">Nama Menu</th>';
    echo '<th scope="col">Harga</th>';
    echo '<th scope="col">Status</th>';
    echo '<th scope="col">Edit</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';

    while ($row = $result->fetch_assoc()) {
        $id_menu = $row["id_menu"];
        $nama_menu = $row["nama_menu"];
        $harga = $row["harga"];
        $status = $row["status"];

        echo '<tr>';
        echo '<td>' . $id_menu . '</td>';
        echo '<td>' . $nama_menu . '</td>';
        echo '<td>' . $harga . '</td>';
        echo '<td>' . $status . '</td>';
        echo '<td><a href="edit_menu.php?id=' . $id_menu . '">Edit</a></td>'; // Tambahkan tombol Edit dengan link ke halaman edit.php dengan parameter id_menu
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
} else {
    echo "No records found";
}

$con->close();
?>


    </div>
</div>
</div>
</div>
</div>









    <!-- script -->
 <script>
        $(document).ready(function() {
            $(".navbar-toggler").click(function() {
                $("#navbarNav").collapse("toggle");
            });
        });

        // tombol pop up edit meja
        const form = document.getElementById('mejaForm');
        const checkboxes = form.querySelectorAll('input[type="checkbox"]');
        const editMejaDiv = document.getElementById('editmeja');
        let isMoving = false;
        let offsetX = 0;
        let offsetY = 0;

        checkboxes.forEach(function(checkbox) {
            checkbox.addEventListener('click', function() {
                if (checkbox.checked) {
                    const selectedMeja = checkbox.value;
                    editMejaDiv.style.display = 'block';
                    const nomorMejaInput = editMejaDiv.querySelector('#editNomorMeja');
                    nomorMejaInput.value = selectedMeja;
                } else {
                    editMejaDiv.style.display = 'none';
                }
            });
        });

        editMejaDiv.addEventListener('mousedown', function(e) {
            isMoving = true;
            offsetX = e.clientX - editMejaDiv.offsetLeft;
            offsetY = e.clientY - editMejaDiv.offsetTop;
        });

        document.addEventListener('mousemove', function(e) {
            if (isMoving) {
                editMejaDiv.style.left = e.clientX - offsetX + 'px';
                editMejaDiv.style.top = e.clientY - offsetY + 'px';
            }
        });

        document.addEventListener('mouseup', function() {
            isMoving = false;
        });


        const editButtons = document.querySelectorAll('.editButton');
        editButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const selectedMeja = button.getAttribute('data-meja');
                const editMejaDiv = document.getElementById('editmeja');
                editMejaDiv.style.display = 'block';

                const nomorMejaInput = editMejaDiv.querySelector('#editNomorMeja');
                nomorMejaInput.value = selectedMeja;
            });
        });
    </script>

</body>

</html>