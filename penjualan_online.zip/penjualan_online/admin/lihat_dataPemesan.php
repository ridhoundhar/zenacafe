<?php
    $nama_pemesan = $_GET['nama_pemesan'];
    include "../koneksi.php";

    $query = "SELECT * FROM reservasi WHERE nama_pemesan = '" . mysqli_real_escape_string($con, $nama_pemesan) . "'";
    $result = mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pemesan</title>
    <link rel="icon" href="assets/img/logo.jpeg" type="image/png">


    <!-- css -->
    <link rel="stylesheet" href="assets/css/history.css">

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

    <!-- CDN FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>

    </style>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
            <img src="assets/img/baju1.jpeg" alt="Admin Logo" width="30" height="30" class="d-inline-block align-top">
            Zena Cafe
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Settings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="list-group">
                    <a href="index.php" class="list-group-item list-group-item-action">Dashboard</a>
                    <a href="Meja.php" class="list-group-item list-group-item-action">Meja</a>
                    <a href="menu.php" class="list-group-item list-group-item-action">Menu</a>
                    <a href="history.php" class="list-group-item list-group-item-action active">Reports</a>
                </div>
            </div>
            <div class="col-md-9"><br>
                <div class="flex-container container_content">
                    <div class="container">
                        <h1>Data Pemesanan</h1>
                        <div class="card">
                            <div class="card-body">
                                <?php
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<p><strong>ID Meja:</strong> " . $row['id_meja'] . "</p>";
                                    echo "<p><strong>Nama Pemesan:</strong> " . $row['nama_pemesan'] . "</p>";
                                    echo "<p><strong>No Telepon:</strong> " . $row['telepon_pemesan'] . "</p>";
                                    echo "<p><strong>Waktu:</strong> " . $row['waktu'] . "</p>";
                                    echo "<p><strong>Tanggal:</strong> " . $row['tanggal'] . "</p>";
                                    echo "<p><strong>Pembayaran:</strong> " . $row['metode_pembayaran'] . "</p>";
                                    echo "<p><strong>Status Pembayaran:</strong> " . $row['status_pembayaran'] . "</p>";
                                    echo "<hr>";
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>










    <!-- script -->
    <script>


    </script>

</body>

</html>