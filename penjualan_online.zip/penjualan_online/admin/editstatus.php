<!DOCTYPE html>
<html>

<head>
    <title>Edit Meja</title>
    <link rel="icon" href="assets/img/logo.jpeg" type="image/png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.5/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.5/dist/sweetalert2.all.min.js"></script>


</head>

<body>
    <?php
    $con = mysqli_connect("localhost", "root", "", "penjualan_db");

    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_errno();
        exit();
    }

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $nomor_meja = $_POST["nomor_meja"];
        $status = $_POST["status"];

        $sql = "UPDATE meja SET status = '$status' WHERE nomor_meja = '$nomor_meja'";

        if ($con->query($sql) === true) {
            echo '<script>
                Swal.fire({
                    title: "Data Berhasil Diubah",
                    icon: "success",
                    showCancelButton: false,
                    confirmButtonText: "OK",
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "index.php";
                    }
                });
            </script>';
        } else {
            echo '<script>
                Swal.fire(
                    "Gagal memperbarui data meja",
                    "' . $con->error . '",
                    "error"
                );
            </script>';
        }
    }
    $nomor_meja = $_GET['nomor_meja'];
    $status = $_GET['status'];
    ?>
</body>

</html>