<?php
session_start();

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('Location:login.php');
    exit();
}

$username = $_SESSION['username'];

// jumlah meja
require "../koneksi.php";

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

$sql = "SELECT COUNT(*) AS jumlah_meja FROM meja";
$result = $con->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $jumlah_meja = $row["jumlah_meja"];
} else {
    echo "Error: " . mysqli_error($con);
}

// meja tersedia
$sql = "SELECT COUNT(*) AS jumlah_meja FROM meja WHERE status = 'tersedia'";
$result = $con->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $jumlah_meja_tersedia = $row["jumlah_meja"];
} else {
    echo "Error: " . mysqli_error($con);
}

// pendapatan
$sql = "SELECT SUM(harga) AS total_duit FROM meja";
$result = $con->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $total_duit = $row["total_duit"];
} else {
    echo "Error: " . mysqli_error($con);
}

$con->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="icon" href="assets/img/logo.jpeg" type="image/png">


    <!-- css -->
    <link rel="stylesheet" href="assets/css/history.css">

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

    <!-- CDN FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .d-flex {
            width: 100vh;
            gap: 10px;
        }
    </style>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
            <img src="assets/img/baju1.jpeg" alt="Admin Logo" width="30" height="30" class="d-inline-block align-top">
            Zena Cafe
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="setting.php">Settings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="list-group">
                    <a href="index.php" class="list-group-item list-group-item-action">Dashboard</a>
                    <a href="Meja.php" class="list-group-item list-group-item-action">Meja</a>
                    <a href="menu.php" class="list-group-item list-group-item-action">Menu</a>
                    <a href="history.php" class="list-group-item list-group-item-action active">Reports</a>
                </div>
            </div>
            <div class="col-md-9">
                <div class="input-group">
                    <form class="d-flex" method="POST" action="">
                        <input class="me-2 form-control" type="search" placeholder="Search" aria-label="Search"
                            name="search">
                        <button class="btn btn-outline-primary" type="submit">Search</button>
                    </form>
                    <div class="container mt-5">
                        <?php
                            
                            include "../koneksi.php";

                            if (isset($_POST['search'])) {
                                $searchValue = $_POST['search'];

                                // Cari di tabel 'reservasi'
                                $queryReservasi = "SELECT * FROM reservasi WHERE nama_pemesan LIKE '%$searchValue%' OR email_pemesan LIKE '%$searchValue%'";
                                $resultReservasi = mysqli_query($con, $queryReservasi);

                                // Cari di tabel 'menu_reservasi'
                                $queryMenuReservasi = "SELECT * FROM menu_reservasi WHERE id_menu LIKE '%$searchValue%' OR email_pemesan LIKE '%$searchValue'";
                                $resultMenuReservasi = mysqli_query($con, $queryMenuReservasi);

                                if ($resultReservasi && $resultMenuReservasi) {
                                    $reservasiCount = mysqli_num_rows($resultReservasi);
                                    $menuReservasiCount = mysqli_num_rows($resultMenuReservasi);

                                    if ($reservasiCount > 0 || $menuReservasiCount > 0) {

                                        if ($reservasiCount > 0) {
                                            echo "<table class='table'>";
                                            echo "<thead>";
                                            echo "<tr>";
                                            echo "<th>ID Meja</th>";
                                            echo "<th>Tanggal</th>";
                                            echo "<th>Waktu</th>";
                                            echo "<th>Nama Pemesan</th>";
                                            echo "<th>Email Pemesan</th>";
                                            echo "<th>Telepon Pemesan</th>";
                                            echo "<th>Metode Pembayaran</th>";
                                            echo "</tr>";
                                            echo "</thead>";
                                            echo "<tbody>";

                                            while ($row = mysqli_fetch_assoc($resultReservasi)) {
                                                echo "<tr>";
                                                echo "<td>" . $row['id_meja'] . "</td>";
                                                echo "<td>" . $row['tanggal'] . "</td>";
                                                echo "<td>" . $row['waktu'] . "</td>";
                                                echo "<td>" . $row['nama_pemesan'] . "</td>";
                                                echo "<td>" . $row['email_pemesan'] . "</td>";
                                                echo "<td>" . $row['telepon_pemesan'] . "</td>";
                                                echo "<td>" . $row['metode_pembayaran'] . "</td>";
                                                echo "</tr>";
                                            }

                                            echo "</tbody>";
                                            echo "</table>";
                                        }

                                        if ($menuReservasiCount > 0) {
                                            echo "<table class='table'>";
                                            echo "<thead>";
                                            echo "<tr>";
                                            echo "<th>ID Menu</th>";
                                            echo "<th>Tanggal</th>";
                                            echo "<th>Waktu</th>";
                                            echo "<th>Nama Pemesan</th>";
                                            echo "<th>Email Pemesan</th>";
                                            echo "<th>Telepon Pemesan</th>";
                                            echo "<th>Metode Pembayaran</th>";
                                            echo "</tr>";
                                            echo "</thead>";
                                            echo "<tbody>";

                                            while ($row = mysqli_fetch_assoc($resultMenuReservasi)) {
                                                echo "<tr>";
                                                echo "<td>" . $row['id_menu'] . "</td>";
                                                echo "<td>" . $row['tanggal'] . "</td>";
                                                echo "<td>" . $row['waktu'] . "</td>";
                                                echo "<td>" . $row['nama_pemesan'] . "</td>";
                                                echo "<td>" . $row['email_pemesan'] . "</td>";
                                                echo "<td>" . $row['telepon_pemesan'] . "</td>";
                                                echo "<td>" . $row['metode_pembayaran'] . "</td>";
                                                echo "</tr>";
                                            }

                                            echo "</tbody>";
                                            echo "</table>";
                                        }
                                    } else {
                                        echo "No data found.";
                                    }
                                } else {
                                    echo "Query error: " . mysqli_error($con);
                                }

                                mysqli_free_result($resultReservasi);
                                mysqli_free_result($resultMenuReservasi);
                                mysqli_close($con);
                            }
                        ?>

                    </div>
                </div><br>
                <div class="flex-container container_content">
                    <div class="box">
                        <h5>Laporan Meja</h5>
                        <?php
                        // Koneksi ke database
                        
                        include "../koneksi.php";

                        // Mengambil data dari tabel reservasi
                        $query = "SELECT * FROM reservasi";
                        $result = mysqli_query($con, $query);

                        // Menampilkan data dalam tabel
                        ?>
                        <!-- history -->
                        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                            <table class="table">
                                <tr>
                                    <td>
                                        <?php echo $row['id_meja']; ?>
                                    </td>
                                    <td>
                                        <?php echo $row['nama_pemesan']; ?>
                                    </td>
                                    <td>
                                        <?php echo $row['waktu']; ?>
                                        <?php echo $row['tanggal']; ?>
                                    </td>
                                    <td><a
                                            href="lihat_dataPemesan.php?nama_pemesan=<?php echo urlencode($row['nama_pemesan']); ?>">Lihat</a>
                                    </td>
                                </tr>
                            </table>
                        <?php } ?>


                    </div>
                    <div class="box">
                        <h5>Laporan Menu</h5>
                        <?php
                        // Koneksi ke database
                        
                        include "../koneksi.php";

                        // Mengambil data dari tabel reservasi
                        $query = "SELECT * FROM menu_reservasi";
                        $result = mysqli_query($con, $query);

                        ?>
                        <!-- history -->
                        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                            <table class="table">
                                <tr>
                                    <td>
                                        <?php echo $row['id_menu']; ?>
                                    </td>
                                    <td>
                                        <?php echo $row['nama_pemesan']; ?>
                                    </td>
                                    <td>
                                        <?php echo $row['waktu']; ?>
                                        <?php echo $row['tanggal']; ?>
                                    </td>
                                    <td><a
                                            href="lihat_menu.php?nama_pemesan=<?php echo urlencode($row['nama_pemesan']); ?>">Lihat</a>
                                    </td>
                                </tr>
                            </table>
                        <?php } ?>


                    </div>
                </div>




                <!-- isi content daftar meja -->
            </div>

        </div>
    </div>










    <!-- script -->
    <script>


    </script>

</body>

</html>