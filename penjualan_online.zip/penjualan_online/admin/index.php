<?php
session_start();

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('Location:login.php');
    exit();
}

$username = $_SESSION['username'];

// jumlah meja
require "../koneksi.php";

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}
// booking
$sql = "SELECT COUNT(*) AS jumlah_meja FROM meja";
$result = $con->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    $jumlah_meja = $row["jumlah_meja"];
} else {
    echo "Error: " . mysqli_error($con);
}


// menu
$sql = "SELECT COUNT(*) AS jumlah_menu FROM menu";
$result = $con->query($sql);
if ($result) {
    $row = $result->fetch_assoc();
    $jumlah_menu = $row["jumlah_menu"];
} else {
    echo "Error: " . mysqli_error($con);
}

$con->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="icon" href="assets/img/logo.jpeg" type="image/png">


    <!-- css -->
    <link rel="stylesheet" href="assets/css/index.css">

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

    <!-- CDN FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    .box-1 {
        background-color: #847c26;
        box-shadow: 1px 1px 5px;
        border: 1px solid #8e8282;
        border-radius: 4px;
        padding: 20px;
        font-size: 12px;
        color: white;
        border-radius: 5px;
    }
    .box-1 a,
    .box-2 a {
        color: white;
    }
    .box-2 {
        background-color: #266884;
        box-shadow: 1px 1px 5px;
        border: 1px solid #8e8282;
        border-radius: 4px;
        padding: 20px;
        color: white;
        font-size: 12px;
        border-radius: 5px;
        box-sizing: border-box;
        }
</style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
            <img src="assets/img/baju1.jpeg" alt="Admin Logo" width="30" height="30" class="d-inline-block align-top">
            Zena Cafe
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="#">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="setting.php">Settings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="list-group">
                    <a href="index.php" class="list-group-item list-group-item-action active">Dashboard</a>
                    <a href="Meja.php" class="list-group-item list-group-item-action">Meja</a>
                    <a href="menu.php" class="list-group-item list-group-item-action">Menu</a>
                    <a href="history.php" class="list-group-item list-group-item-action">Reports</a>
                </div>
            </div>
            <div class="col-md-9">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search...">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="button">Search</button>
                    </div>
                </div><br>
                <h3>Kategori</h3>
                <div class="flex-container container_content">
                    <div class="d-flex col-5 box-1">
                        <h1><i class="fa-sharp fa-solid fa-list"></i></h1>
                        <div class="col-4">
                            <h3><?php echo $jumlah_meja;?></h3>
                            <div><a href="meja.php">Booking</a></div>
                        </div>
                    </div>
                    <div class="d-flex col-5 box-2">
                        <h1><i class="fa-sharp fa-solid fa-list"></i></h1>
                        <div class="col-5">
                            <h3><?php echo $jumlah_menu;?></h3>
                            <div><a href="menu.php">Menu</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>










    <!-- script -->
    <script>
        
    </script>

</body>

</html>