<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        .seat-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
            max-width: 500px;
            margin: 0 auto;
        }

        .seat {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            height: 50px;
            border: 2px solid #ccc;
            background-color: #fff;
        }

        .available {
            background-color: #c3e6cb;
        }

        .occupied {
            background-color: #f8d7da;
        }

        .selected {
            background-color: #007bff;
            color: #fff;
        }

        .booking-btn {
            padding: 5px 10px;
            background-color: #fff;
            border: 1px solid #ccc;
            cursor: pointer;
        }

        .booking-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
    </style>

</head>

<body>

    <div class="meja">
        <?php
        $con = mysqli_connect("localhost", "root", "", "penjualan_db");

        if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            exit();
        }

        // Fetch the table data
        $sql = "SELECT * FROM meja";
        $result = mysqli_query($con, $sql);

        // Check for query error
        if (!$result) {
            echo "Error retrieving data from the database: " . mysqli_error($con);
            exit();
        }

        // Display the data as evenly arranged boxes with seat numbers using flexbox
        echo "<div class='seat-container'>";

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $seatClass = ($row['status'] == 'occupied') ? 'occupied' : 'available';
                echo "<div class='seat " . $seatClass . "' onclick='selectSeat(this)'>";
                echo "<span class='seat-number'>" . $row["nomor_meja"] . "</span>";

                if ($row['status'] == 'available') {
                    echo "<button class='booking-btn'>Booking</button>";
                }

                echo "</div>";
            }
        } else {
            echo "<p>No data available</p>";
        }

        echo "</div>";

        // Close the database connection
        mysqli_close($con);
        ?>

        <script>
            function selectSeat(seat) {
                seat.classList.toggle('selected');

                var bookingBtn = seat.querySelector('.booking-btn');
                if (bookingBtn) {
                    bookingBtn.disabled = !seat.classList.contains('selected');
                }

                if (seat.classList.contains('selected')) {
                    var seatNumber = seat.querySelector('.seat-number').textContent;
                    var selectedSeats = document.getElementById('selected-seats');
                    selectedSeats.textContent += seatNumber + ', ';
                } else {
                    var seatNumber = seat.querySelector('.seat-number').textContent;
                    var selectedSeats = document.getElementById('selected-seats');
                    selectedSeats.textContent = selectedSeats.textContent.replace(seatNumber + ', ', '');
                }
            }
        </script>

        <p>Selected Seats: <span id="selected-seats"></span></p>


    </div>


</body>

</html>