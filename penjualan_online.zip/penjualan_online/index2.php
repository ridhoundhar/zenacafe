<!DOCTYPE html>
<html>

<head>
    <title>Reservasi Search</title>
    <!-- Include the necessary Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <form class="d-flex" method="POST" action="">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"
                        name="search">
                    <button class="btn btn-outline-primary" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <?php
        // Koneksi ke database
        $con = mysqli_connect("localhost", "root", "", "penjualan_db");

        if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_errno();
            exit();
        }

        if (isset($_POST['search'])) {
            $searchValue = $_POST['search'];

            // Mengambil data dari tabel reservasi berdasarkan kata kunci pencarian
            $query = "SELECT * FROM reservasi WHERE nama_pemesan LIKE '%$searchValue%' OR email_pemesan LIKE '%$searchValue%'";
            $result = mysqli_query($con, $query);

            // Memeriksa apakah query berhasil dijalankan
            if ($result) {
                // Memeriksa apakah ada baris data yang ditemukan
                if (mysqli_num_rows($result) > 0) {
                    // Menampilkan data reservasi dalam bentuk tabel
                    echo "<table class='table'>";
                    echo "<tr><th>ID Meja</th><th>Tanggal</th><th>Waktu</th><th>Nama Pemesan</th><th>Email Pemesan</th><th>Telepon Pemesan</th><th>Metode Pembayaran</th></tr>";

                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['id_meja'] . "</td>";
                        echo "<td>" . $row['tanggal'] . "</td>";
                        echo "<td>" . $row['waktu'] . "</td>";
                        echo "<td>" . $row['nama_pemesan'] . "</td>";
                        echo "<td>" . $row['email_pemesan'] . "</td>";
                        echo "<td>" . $row['telepon_pemesan'] . "</td>";
                        echo "<td>" . $row['metode_pembayaran'] . "</td>";
                        echo "</tr>";
                    }

                    echo "</table>";
                } else {
                    echo "No data found.";
                }
            } else {
                echo "Query error: " . mysqli_error($con);
            }

            mysqli_free_result($result);
            mysqli_close($con);
        }
        ?>
    </div>

    <!-- Include the necessary Bootstrap JavaScript file -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>